﻿class Program
{
    static void Main(string[] args)
    {
      
        VagaEstacionamento vaga101 = new VagaEstacionamento(101, "Carro");

        vaga101.ExibirInformacoes();
        Console.WriteLine();
       
        vaga101.OcuparVaga();
        vaga101.ExibirInformacoes();
        Console.WriteLine();
       
        vaga101.AlterarTipoVeiculo("Moto");
        Console.WriteLine();
   
        vaga101.LiberarVaga();
        vaga101.ExibirInformacoes();
        Console.WriteLine();
       
        vaga101.AlterarTipoVeiculo("Moto");
        vaga101.ExibirInformacoes();
    }
}