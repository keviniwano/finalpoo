﻿using System;

public class Funcionario
{
    public string NomeCompleto { get; set; }
    public double Salario { get; set; }

 
    public virtual void ExibirDados()
    {
        string[] nomes = NomeCompleto.Split(' ');
        string ultimoSobrenome = nomes[nomes.Length - 1].ToUpper();

      
        string salarioFormatado = Salario.ToString("C", new System.Globalization.CultureInfo("pt-BR"));

        Console.WriteLine($"Último sobrenome: {ultimoSobrenome}");
        Console.WriteLine($"Salário: {salarioFormatado}");
    }
}

public class Gerente : Funcionario
{
    public string Departamento { get; set; }

    
    public override void ExibirDados()
    {
        base.ExibirDados();

        Console.WriteLine($"Departamento: {Departamento}");

      
        if (Salario > 10000)
        {
            Console.WriteLine("Status: Alta Gestão.");
        }
    }
}

class Program
{
    static void Main(string[] args)
    {
      
        Funcionario funcionario1 = new Funcionario
        {
            NomeCompleto = "João da Silva",
            Salario = 4500.00
        };

        Gerente gerente1 = new Gerente
        {
            NomeCompleto = "Maria Oliveira",
            Salario = 12000.00,
            Departamento = "TI"
        };

     
        Console.WriteLine("Dados do Funcionário:");
        funcionario1.ExibirDados();
        Console.WriteLine();

        Console.WriteLine("Dados do Gerente:");
        gerente1.ExibirDados();
    }
}