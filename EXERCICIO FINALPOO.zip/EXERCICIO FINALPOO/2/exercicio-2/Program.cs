﻿using System;

public class Calculo
{
    public double ValorA { get; set; }
    public double ValorB { get; set; }
    public double Resultado { get; private set; }

 
    public void CalcularSoma()
    {
        Resultado = ValorA + ValorB;
    }

   
    public void CalcularSubtracao()
    {
        Resultado = ValorA - ValorB;
    }

    
    public void CalcularMultiplicacao()
    {
        Resultado = ValorA * ValorB;
    }

 
    public double RetornarMaior()
    {
        return ValorA > ValorB ? ValorA : ValorB;
    }

 
    public double SomarGeral(double valor)
    {
        return ValorA + ValorB + valor;
    }
}

public class Calculadora
{
    private Calculo _calculo;

    public Calculadora()
    {
        _calculo = new Calculo();
    }

   
    public void LerValores()
    {
        Console.Write("Digite o valor de A: ");
        _calculo.ValorA = Convert.ToDouble(Console.ReadLine());

        Console.Write("Digite o valor de B: ");
        _calculo.ValorB = Convert.ToDouble(Console.ReadLine());
    }

    
    public void ImprimirResultado()
    {
        Console.WriteLine($"Resultado: {_calculo.Resultado}");
    }



    public void ExecutarCalculadora()
    {
        LerValores();

        while (true)
        {
            Console.WriteLine("\nSelecione uma operação:");
            Console.WriteLine("1. Somar");
            Console.WriteLine("2. Subtrair");
            Console.WriteLine("3. Multiplicar");
            Console.WriteLine("4. Maior Valor");
            Console.WriteLine("5. Somar Valor Geral");
            Console.WriteLine("6. Sair");
            Console.Write("Opção: ");

            string opcao = Console.ReadLine();

            switch (opcao)
            {
                case "1":
                    _calculo.CalcularSoma();
                    ImprimirResultado();
                    break;
                case "2":
                    _calculo.CalcularSubtracao();
                    ImprimirResultado();
                    break;
                case "3":
                    _calculo.CalcularMultiplicacao();
                    ImprimirResultado();
                    break;
                case "4":
                    double maior = _calculo.RetornarMaior();
                    Console.WriteLine($"Maior valor: {maior}");
                    break;
                case "5":
                    Console.Write("Digite um valor para somar: ");
                    double valorGeral = Convert.ToDouble(Console.ReadLine());
                    double resultadoGeral = _calculo.SomarGeral(valorGeral);
                    Console.WriteLine($"Resultado da soma geral: {resultadoGeral}");
                    break;
                case "6":
                    Console.WriteLine("Saindo...");
                    return;
                default:
                    Console.WriteLine("Opção inválida. Tente novamente.");
                    break;
            }
        }
    }
}

class Program
{
    static void Main(string[] args)
    {
        Calculadora calculadora = new Calculadora();
        calculadora.ExecutarCalculadora();
    }
}